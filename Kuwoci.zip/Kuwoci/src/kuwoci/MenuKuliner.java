/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.text.View;

/**
 *
 * @author lenovo
 */
public class MenuKuliner {
    private String nama;
    private int harga;
    private String deskripsi;
    public MenuKuliner(String nama, int harga, String deskripsi){
        setNama(nama);
        setHarga(harga);
        setDesc(deskripsi);
    }
    //setter
    public void setNama(String nama){
        this.nama =nama;
    }
    public void setHarga(int harga){
        this.harga = harga;
    }
    public void setDesc(String deskripsi){
        this.deskripsi = deskripsi;
    }
    //getter
    public String getNama(){
        return nama;
    }
    public int getHarga(){
        return harga;
    }
    public String getDesc(){
        return deskripsi;
    }
    public void insertMenu() throws SQLException{
        Connection dbconn = Kuwoci.koneksiDB();           
        String price = String.valueOf(harga);
        PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement("INSERT INTO menukuliner (nama,harga,deskripsi) VALUES "
                + "('"+this.getNama()+"','"+price+"','"+this.getDesc()+"')");
        int hasil = st.executeUpdate();                         
    }
    public void deleteMenu()throws SQLException{
        Connection dbconn = Kuwoci.koneksiDB();                 
        String sql = "delete from menukuliner WHERE nama = '"+this.getNama()+"'" ;
        PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement(sql);
        int hasil = st.executeUpdate();
    }
    public void updateMenu(String namaMenu) throws SQLException{
        Connection dbconn = Kuwoci.koneksiDB();
        String price = String.valueOf(harga);
        String sql = "UPDATE `makanan`.`menukuliner` SET `nama` = '"+this.getNama()+"', "
                + "`harga` = '"+price+"', `deskripsi` = '"+this.getDesc()+"' where (`nama`='"+namaMenu+"')";          
        PreparedStatement st = dbconn.prepareStatement(sql);
        st.executeUpdate();
    }
}
