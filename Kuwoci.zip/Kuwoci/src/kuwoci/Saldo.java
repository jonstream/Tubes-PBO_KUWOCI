/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import static kuwoci.Konsumen_homepage.namauser;
import static kuwoci.Konsumen_homepage.saldo;
import static kuwoci.LoginUser.emailUsr;


/**
 *
 * @author lenovo
 */
public class Saldo {
    private int saldo;
    private String user;
    Connection dbconn = Kuwoci.koneksiDB();
    public Saldo(int saldo, String user){
        setSaldo(saldo);
        setuser(user);
    }
    public void setSaldo(int saldo){
        this.saldo =saldo;
    }
    public void setuser(String user){
        this.user = user;
    }
    public int getSaldo(){
        return saldo;
    }
    public String getuser(){
        return user;
    }
    public void topUp() throws SQLException{
        String sql = "UPDATE makanan.customer SET saldo = '"+this.getSaldo()+"' where (email='"+this.getuser()+"')";
        PreparedStatement st = dbconn.prepareStatement(sql);
        st.executeUpdate();
    }
}
