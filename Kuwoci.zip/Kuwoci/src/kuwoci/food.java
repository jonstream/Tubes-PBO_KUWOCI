/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static kuwoci.Konsumen_homepage.namauser;
import static kuwoci.Konsumen_homepage.saldo;
import static kuwoci.LoginUser.emailUsr;
import static kuwoci.Wishlist_UI.KrjHarga;
import static kuwoci.Wishlist_UI.KrjMenu;
import static kuwoci.Wishlist_UI.KrjQty;
import static kuwoci.Wishlist_UI.KrjTotal;

/**
 *
 * @author lenovo
 */
public class food extends javax.swing.JFrame {

    /**
     * Creates new form food
     */
    String billNo="";
    public String bal;
    Double totalAmount=0.0;
    Double cash=0.0;
    Double balance=0.0;
    public Double bHeight=0.0;
    public int lunas; 
    public int sum;
    public int curSaldo;
    
    public static ArrayList<String> NamaMenu = new ArrayList<>();
    public static ArrayList<Integer> quantity = new ArrayList<>();
    public static ArrayList<Integer> HargaPerItem = new ArrayList<>();
    public static ArrayList<Integer> subtotal = new ArrayList<>();
    
    //harga menu
    public int empal_G;
    public int empal_A;
    public int Nasi_jbl;
    public int Nasi_lk;
    public int sate_A;
    public int sate_K;
    public int pds_etg;
    public int Bbr_sop;
    public int ketoprak;
    public int gado_a;
    public int dcg;
    public int rujak_k;
    public int tahu_gjr;
    public int surabi;
    public int krpk_u;
    public int krpk_k;
    public int kue_gpit;
    public int emping;

    public int tjampolay;
    public int teh_poci;
    public int sekuteng;
    public int hrg_cuing;
    public int es_cdl;
    public int es_twr;
    public int es_cpr;

    public food() {
        initComponents();   
        if(KrjMenu.size()>0){
            wishlistCart();
        }
        txtTotal.setText("Rp"+" "+Integer.toString(sum));
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Empal Gentong'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                empal_G = rs.getInt("harga");
                String empalGtg = rs.getString("harga");
                jLabel26.setText("Rp"+" "+ empalGtg);
            }else{
                 jLabel26.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Empal Asem
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Empal Asem'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                empal_A = rs.getInt("harga");
                String empalAsm = rs.getString("harga");
                jLabel27.setText("Rp"+" "+ empalAsm);
            }else{
                 jLabel27.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Nasi Jamblang
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Nasi Jamblang'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                Nasi_jbl = rs.getInt("harga");
                String NasiJ = rs.getString("harga");
                jLabel28.setText("Rp"+" "+ NasiJ);
            }else{
                 jLabel28.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Nasi Lengko
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Nasi Lengko'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                Nasi_lk = rs.getInt("harga");
                String NasiL = rs.getString("harga");
                jLabel29.setText("Rp"+" "+ NasiL);
            }else{
                 jLabel29.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Sate Ayam
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Sate Ayam'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                sate_A = rs.getInt("harga");
                String Sayam = rs.getString("harga");
                jLabel30.setText("Rp"+" "+ Sayam);
            }else{
                 jLabel30.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Sate Kambing
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Sate Kambing'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                sate_K = rs.getInt("harga");
                String SKambing = rs.getString("harga");
                jLabel31.setText("Rp"+" "+ SKambing);
            }else{
                 jLabel31.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Pedesan Entog
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Pedesan Entog'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                pds_etg = rs.getInt("harga");
                String PDS = rs.getString("harga");
                jLabel32.setText("Rp"+" "+ PDS);
            }else{
                 jLabel32.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Bubur Sop Ayam
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Bubur Sop Ayam'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                Bbr_sop = rs.getInt("harga");
                String BSA = rs.getString("harga");
                jLabel33.setText("Rp"+" "+ BSA);
            }else{
                 jLabel33.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Ketoprak
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Ketoprak'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                ketoprak = rs.getInt("harga");
                String KTR = rs.getString("harga");
                jLabel34.setText("Rp"+" "+ KTR);
            }else{
                 jLabel34.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Gado-gado Ayam
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Gado-gado Ayam'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                gado_a = rs.getInt("harga");
                String GDA = rs.getString("harga");
                jLabel35.setText("Rp"+" "+ GDA);
            }else{
                 jLabel35.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }        
         //Docang
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Docang'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                dcg = rs.getInt("harga");
                String Docang = rs.getString("harga");
                jLabel36.setText("Rp"+" "+ Docang);
            }else{
                 jLabel36.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }              
        //Rujak Kangkung
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Rujak Kangkung'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                rujak_k = rs.getInt("harga");
                String RJK = rs.getString("harga");
                jLabel37.setText("Rp"+" "+ RJK);
            }else{
                 jLabel37.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Tahu Gejrot
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Tahu Gejrot'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                tahu_gjr = rs.getInt("harga");
                String TG = rs.getString("harga");
                jLabel38.setText("Rp"+" "+ TG);
            }else{
                 jLabel38.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Serabi
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Serabi'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                surabi = rs.getInt("harga");
                String SRB = rs.getString("harga");
                jLabel39.setText("Rp"+" "+ SRB);
            }else{
                 jLabel39.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Kerupuk Udang
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Kerupuk Udang'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                krpk_u = rs.getInt("harga");
                String KRU = rs.getString("harga");
                jLabel40.setText("Rp"+" "+ KRU);
            }else{
                 jLabel40.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Kerupuk Kulit
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Kerupuk Kulit'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                krpk_k = rs.getInt("harga");
                String KRK = rs.getString("harga");
                jLabel41.setText("Rp"+" "+ KRK);
            }else{
                 jLabel41.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Gapit
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Kue Gapit'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                kue_gpit = rs.getInt("harga");
                String GPT = rs.getString("harga");
                jLabel42.setText("Rp"+" "+ GPT);
            }else{
                 jLabel42.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Emping
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Emping'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                emping= rs.getInt("harga");
                String EPG = rs.getString("harga");
                jLabel43.setText("Rp"+" "+ EPG);
            }else{
                 jLabel43.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        
        jfood1.setText("Empal Gentong");
        jfood2.setText("Empal Asem");
        jfood3.setText("Nasi Jamblang");
        jfood4.setText("Nasi Lengko");
        jfood5.setText("Sate Ayam");
        jfood7.setText("Sate Kambing");
        jfood8.setText("Docang");
        jfood9.setText("Bubur Sop Ayam");
        jfood10.setText("Gado-gado Ayam");
        jfood11.setText("Pedesan Entog");
        jfood12.setText("Rujak Kangkung");        
        jfood14.setText("Tahu Gejrot");
        jfood15.setText("Serabi");
        jfood16.setText("Kerupuk Udang");
        jfood17.setText("Kerupuk Kulit");
        jfood18.setText("Kue Gapit");
        jfood19.setText("Emping");
        
        ////////////////////////////////////////////////Menu Minuman////////////////////////////////////////////////////////
     
        //Sirup Tjampolya
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Sirup Tjampolay'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                tjampolay = rs.getInt("harga");
                String STJ = rs.getString("harga");
                jlb1.setText("Rp"+" "+ STJ);
            }else{
                jlb1.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Teh Poci
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Teh Poci'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                teh_poci = rs.getInt("harga");
                String Poci = rs.getString("harga");
                jlb2.setText("Rp"+" "+ Poci);
            }else{
                 jlb2.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Sekoteng
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Sekoteng'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                sekuteng = rs.getInt("harga");
                String SKT = rs.getString("harga");
                jlb3.setText("Rp"+" "+ SKT);
            }else{
                 jlb3.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Cuing
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Cuing'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                hrg_cuing = rs.getInt("harga");
                String Cuing = rs.getString("harga");
                jlb4.setText("Rp"+" "+ Cuing);
            }else{
                 jlb4.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Es Cendol
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Es Cendol'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                es_cdl = rs.getInt("harga");
                String CDL = rs.getString("harga");
                jlb5.setText("Rp"+" "+ CDL);
            }else{
                 jlb5.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
         //Es Tawuran
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Es Tawuran'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                es_twr = rs.getInt("harga");
                String ET = rs.getString("harga");
                jlb6.setText("Rp"+" "+ ET);
            }else{
                 jlb6.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        //Es Campur
        try{
            Connection dbconn = Kuwoci.koneksiDB();
            String sql = "select harga from makanan.menukuliner where nama = 'Es Campur'";
            Statement st = dbconn.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql); 
            if(rs.next()){
                es_cpr = rs.getInt("harga");
                String EC = rs.getString("harga");
                jlb7.setText("Rp"+" "+ EC);
            }else{
                 jlb7.setText("");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Tidak ada data pada database");
        }
        
        jdrink1.setText("Sirup Tjampolay");
        jdrink2.setText("Teh Poci");
        jdrink3.setText("Sekoteng");
        jdrink4.setText("Cuing");
        jdrink5.setText("Es Cendol");
        jdrink6.setText("Es Tawuran");
        jdrink7.setText("Es Campur");
        
        
        
 
    }
    
    
    DefaultTableModel model = new DefaultTableModel();
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        keranjang = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jfood1 = new javax.swing.JButton();
        jfood2 = new javax.swing.JButton();
        jfood3 = new javax.swing.JButton();
        jfood4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jfood5 = new javax.swing.JButton();
        jfood7 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jfood8 = new javax.swing.JButton();
        jfood9 = new javax.swing.JButton();
        jfood10 = new javax.swing.JButton();
        jfood11 = new javax.swing.JButton();
        jfood12 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jfood13 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jfood14 = new javax.swing.JButton();
        jfood15 = new javax.swing.JButton();
        jfood16 = new javax.swing.JButton();
        jfood17 = new javax.swing.JButton();
        jfood18 = new javax.swing.JButton();
        jfood19 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        GtgCart = new javax.swing.JButton();
        GtgQty = new javax.swing.JSpinner();
        AsmCart = new javax.swing.JButton();
        AsmQty = new javax.swing.JSpinner();
        JblCart = new javax.swing.JButton();
        JblQty = new javax.swing.JSpinner();
        LkoCart = new javax.swing.JButton();
        LkoQty = new javax.swing.JSpinner();
        ayamCart = new javax.swing.JButton();
        ayamQty = new javax.swing.JSpinner();
        kbgCart = new javax.swing.JButton();
        KbgQty = new javax.swing.JSpinner();
        entogcart = new javax.swing.JButton();
        entogQty = new javax.swing.JSpinner();
        buryamCart = new javax.swing.JButton();
        buryamQty = new javax.swing.JSpinner();
        kangkunCart = new javax.swing.JButton();
        kangkungQty = new javax.swing.JSpinner();
        KtpCart = new javax.swing.JButton();
        KtpQty = new javax.swing.JSpinner();
        DcgCart = new javax.swing.JButton();
        DcgQty = new javax.swing.JSpinner();
        EpgCart = new javax.swing.JButton();
        EpgQty = new javax.swing.JSpinner();
        KulitCart = new javax.swing.JButton();
        KulitQty = new javax.swing.JSpinner();
        TahuCart = new javax.swing.JButton();
        SrbCart = new javax.swing.JButton();
        SrbQty = new javax.swing.JSpinner();
        TahuQty = new javax.swing.JSpinner();
        GapitQty = new javax.swing.JSpinner();
        UdangQty = new javax.swing.JSpinner();
        GapitCart = new javax.swing.JButton();
        UdangCart = new javax.swing.JButton();
        gadoCart = new javax.swing.JButton();
        gadoQty = new javax.swing.JSpinner();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel7 = new javax.swing.JPanel();
        jdrink1 = new javax.swing.JButton();
        jdrink2 = new javax.swing.JButton();
        jdrink7 = new javax.swing.JButton();
        jdrink4 = new javax.swing.JButton();
        jdrink3 = new javax.swing.JButton();
        jdrink6 = new javax.swing.JButton();
        jdrink5 = new javax.swing.JButton();
        jlb1 = new javax.swing.JLabel();
        jlb2 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jlb5 = new javax.swing.JLabel();
        jlb6 = new javax.swing.JLabel();
        jlb7 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jlb3 = new javax.swing.JLabel();
        jlb4 = new javax.swing.JLabel();
        StjBtn = new javax.swing.JButton();
        StjQty = new javax.swing.JSpinner();
        pociBtn = new javax.swing.JButton();
        pociQty = new javax.swing.JSpinner();
        SktQty = new javax.swing.JSpinner();
        cuingQty = new javax.swing.JSpinner();
        CdlQty = new javax.swing.JSpinner();
        TwrQty = new javax.swing.JSpinner();
        CprQty = new javax.swing.JSpinner();
        SktBtn = new javax.swing.JButton();
        cuingCart = new javax.swing.JButton();
        CdlBtn = new javax.swing.JButton();
        TwrBtn = new javax.swing.JButton();
        CprBtn = new javax.swing.JButton();
        jLabel70 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CheckOutBtn = new javax.swing.JButton();
        ResetBtn = new javax.swing.JButton();
        btnTotal = new javax.swing.JButton();
        HapusBtn = new javax.swing.JButton();
        txtTotal = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 540));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 640, -1, -1));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 770, 70, 60));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Menu Makanan");

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        jfood1.setBackground(new java.awt.Color(255, 255, 255));
        jfood1.setForeground(new java.awt.Color(51, 51, 51));
        jfood1.setText("Empal Gentong");
        jfood1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood1ActionPerformed(evt);
            }
        });

        jfood2.setText("Empal Asem");
        jfood2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood2ActionPerformed(evt);
            }
        });

        jfood3.setText("Nasi Jamblang");
        jfood3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood3ActionPerformed(evt);
            }
        });

        jfood4.setText("Nasi Lengko");
        jfood4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood4ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Empal");

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nasi");

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Sate");

        jfood5.setText("Sate Ayam");
        jfood5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood5ActionPerformed(evt);
            }
        });

        jfood7.setText("Sate Kambing");
        jfood7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood7ActionPerformed(evt);
            }
        });

        jfood8.setText("Docang");
        jfood8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood8ActionPerformed(evt);
            }
        });

        jfood9.setText("Bubur Sop Ayam");
        jfood9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood9ActionPerformed(evt);
            }
        });

        jfood10.setText("Gado-gado Ayam");
        jfood10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood10ActionPerformed(evt);
            }
        });

        jfood11.setText("Pedesan Entog");
        jfood11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood11ActionPerformed(evt);
            }
        });

        jfood12.setText("Rujak Kangkung");
        jfood12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood12ActionPerformed(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\empalgtg1.jpeg")); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\empal-asem1.jpg")); // NOI18N

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\nasi-jamblang.jpg")); // NOI18N

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\nasi-lengko.jpg")); // NOI18N

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\sateayam.jpg")); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\sate-kambing.jpg")); // NOI18N

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Menu Lainnya");

        jfood13.setText("Ketoprak");
        jfood13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood13ActionPerformed(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\bubur-sop-ayam-cirebon-150x150.jpg")); // NOI18N

        jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\PedesanEntog.jpg")); // NOI18N

        jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\gado-gado-ayam.jpg")); // NOI18N

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\rujak-kangkung.jpg")); // NOI18N

        jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\docang.jpg")); // NOI18N

        jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\ketoprak.jpg")); // NOI18N

        jLabel19.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Makanan Ringan");

        jfood14.setText("Tahu Gejrot");
        jfood14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood14ActionPerformed(evt);
            }
        });

        jfood15.setText("Serabi");
        jfood15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood15ActionPerformed(evt);
            }
        });

        jfood16.setText("Kerupuk Udang");
        jfood16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood16ActionPerformed(evt);
            }
        });

        jfood17.setText("Kerupuk Kulit");
        jfood17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood17ActionPerformed(evt);
            }
        });

        jfood18.setText("Kue Gapit");
        jfood18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood18ActionPerformed(evt);
            }
        });

        jfood19.setText("Emping");
        jfood19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jfood19ActionPerformed(evt);
            }
        });

        jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\gjrot.png")); // NOI18N

        jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\serabi.png")); // NOI18N

        jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\peluang-usaha-kerupuk-kulit.jpg")); // NOI18N

        jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\krpkudang.png")); // NOI18N

        jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\gapit.png")); // NOI18N

        jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\emping.png")); // NOI18N

        jLabel26.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("jLabel26");

        jLabel27.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("jLabel27");

        jLabel28.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("jLabel28");

        jLabel29.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("jLabel29");

        jLabel30.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("jLabel30");

        jLabel31.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("jLabel31");

        jLabel32.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("jLabel32");

        jLabel33.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("jLabel33");

        jLabel34.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("jLabel34");

        jLabel35.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("jLabel35");

        jLabel36.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("jLabel36");

        jLabel37.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("jLabel37");

        jLabel38.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("jLabel38");

        jLabel39.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("jLabel39");

        jLabel40.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("jLabel40");

        jLabel41.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("jLabel41");

        jLabel42.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("jLabel42");

        jLabel43.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("jLabel43");

        GtgCart.setText("Add to Cart");
        GtgCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GtgCartActionPerformed(evt);
            }
        });

        GtgQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        AsmCart.setText("Add to Cart");
        AsmCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AsmCartActionPerformed(evt);
            }
        });

        AsmQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        JblCart.setText("Add to Cart");
        JblCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JblCartActionPerformed(evt);
            }
        });

        JblQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        LkoCart.setText("Add to Cart");
        LkoCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LkoCartActionPerformed(evt);
            }
        });

        LkoQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        ayamCart.setText("Add to Cart");
        ayamCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ayamCartActionPerformed(evt);
            }
        });

        ayamQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        kbgCart.setText("Add to Cart");
        kbgCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kbgCartActionPerformed(evt);
            }
        });

        KbgQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        entogcart.setText("Add to Cart");
        entogcart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entogcartActionPerformed(evt);
            }
        });

        entogQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        buryamCart.setText("Add to Cart");
        buryamCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buryamCartActionPerformed(evt);
            }
        });

        buryamQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        kangkunCart.setText("Add to Cart");
        kangkunCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kangkunCartActionPerformed(evt);
            }
        });

        kangkungQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        KtpCart.setText("Add to Cart");
        KtpCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KtpCartActionPerformed(evt);
            }
        });

        KtpQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        DcgCart.setText("Add to Cart");
        DcgCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DcgCartActionPerformed(evt);
            }
        });

        DcgQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        EpgCart.setText("Add to Cart");
        EpgCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EpgCartActionPerformed(evt);
            }
        });

        EpgQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        KulitCart.setText("Add to Cart");
        KulitCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KulitCartActionPerformed(evt);
            }
        });

        KulitQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        TahuCart.setText("Add to Cart");
        TahuCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TahuCartActionPerformed(evt);
            }
        });

        SrbCart.setText("Add to Cart");
        SrbCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SrbCartActionPerformed(evt);
            }
        });

        SrbQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        TahuQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        GapitQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        UdangQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        GapitCart.setText("Add to Cart");
        GapitCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GapitCartActionPerformed(evt);
            }
        });

        UdangCart.setText("Add to Cart");
        UdangCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UdangCartActionPerformed(evt);
            }
        });

        gadoCart.setText("Add to Cart");
        gadoCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gadoCartActionPerformed(evt);
            }
        });

        gadoQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jLabel5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(1602, 4003, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(ayamCart, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                                                    .addComponent(jfood5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ayamQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(DcgCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(jfood8, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(DcgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addComponent(jLabel17))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(gadoCart, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jfood10))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(gadoQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGap(99, 99, 99)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(kbgCart, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(KbgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel11)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jfood7, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel13)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(buryamCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(buryamQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(jLabel16)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jfood12)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(kangkunCart, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(kangkungQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(KtpCart, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jfood13, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(KtpQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(jLabel18))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel8)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(GtgCart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(GtgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(JblCart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(JblQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(95, 95, 95)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(AsmCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(AsmQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(jLabel9)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(LkoCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood4, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(LkoQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(entogcart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jfood11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(entogQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel21)
                                            .addComponent(jLabel23)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(jfood15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(SrbCart, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(19, 19, 19)
                                                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(18, 18, 18)
                                                        .addComponent(SrbQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(UdangCart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jfood16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(UdangQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(86, 86, 86)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel24)
                                            .addComponent(jLabel20)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(TahuCart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                                                    .addComponent(jfood14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(TahuQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(jfood18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(GapitCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(GapitQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                        .addGap(8, 8, 8)
                                                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(EpgCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jfood19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(EpgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(150, 150, 150)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel22)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                            .addComponent(KulitCart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(jfood17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(KulitQty, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                                .addContainerGap(3530, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel19))
                        .addGap(0, 3982, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel2)
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jfood1))
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(GtgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GtgCart))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(29, 29, 29)
                        .addComponent(jLabel8)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jfood3)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JblCart)
                            .addComponent(JblQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jfood2)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AsmQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AsmCart))
                        .addGap(72, 72, 72)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(152, 152, 152)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jfood4)
                                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LkoCart)
                            .addComponent(LkoQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jfood7)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(20, 20, 20)
                        .addComponent(jLabel10)
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jfood5)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ayamCart)
                            .addComponent(ayamQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(kbgCart)
                        .addComponent(KbgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(56, 56, 56)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(244, 244, 244)
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jfood12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(kangkunCart)
                                    .addComponent(kangkungQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jfood11)
                                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(entogcart)
                                            .addComponent(entogQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel33)
                                            .addComponent(jfood9))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(buryamCart)
                                            .addComponent(buryamQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(39, 39, 39)
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jfood10)
                                    .addComponent(jLabel35))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(gadoCart)
                                    .addComponent(gadoQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(67, 67, 67)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood8, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DcgCart)
                            .addComponent(DcgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jfood13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(KtpCart)
                            .addComponent(KtpQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(55, 55, 55)
                .addComponent(jLabel19)
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood19)
                            .addComponent(jLabel43)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood17)
                            .addComponent(jLabel41))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(EpgCart)
                        .addComponent(EpgQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(KulitCart)
                        .addComponent(KulitQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(131, 131, 131)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood14)
                            .addComponent(jLabel38))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TahuCart)
                            .addComponent(TahuQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood15)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SrbCart)
                            .addComponent(SrbQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(109, 109, 109)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jfood16)
                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel24)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jfood18)
                            .addComponent(jLabel42))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(GapitQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(GapitCart))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(UdangQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UdangCart)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6157, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(198, 198, 198))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 449, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Makanan", jPanel2);

        jPanel6.setBackground(new java.awt.Color(153, 153, 153));

        jScrollPane3.setBackground(new java.awt.Color(204, 204, 204));

        jPanel7.setBackground(new java.awt.Color(102, 102, 102));

        jdrink1.setText("Sirup Tjampolay");
        jdrink1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink1ActionPerformed(evt);
            }
        });

        jdrink2.setText("Teh Poci");
        jdrink2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink2ActionPerformed(evt);
            }
        });

        jdrink7.setText("Es Campur");
        jdrink7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink7ActionPerformed(evt);
            }
        });

        jdrink4.setText("Cuing");
        jdrink4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink4ActionPerformed(evt);
            }
        });

        jdrink3.setText("Sekoteng");
        jdrink3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink3ActionPerformed(evt);
            }
        });

        jdrink6.setText("Es Tawuran");
        jdrink6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink6ActionPerformed(evt);
            }
        });

        jdrink5.setText("Es Cendol");
        jdrink5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdrink5ActionPerformed(evt);
            }
        });

        jlb1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb1.setForeground(new java.awt.Color(255, 255, 255));
        jlb1.setText("jLabel1");

        jlb2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb2.setForeground(new java.awt.Color(255, 255, 255));
        jlb2.setText("jLabel2");

        jLabel61.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\poci2.png")); // NOI18N

        jLabel62.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\tjampolay.jpg")); // NOI18N

        jLabel63.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\sktg.jpg")); // NOI18N

        jLabel64.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\cuing.jpg")); // NOI18N

        jlb5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb5.setForeground(new java.awt.Color(255, 255, 255));
        jlb5.setText("jLabel5");

        jlb6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb6.setForeground(new java.awt.Color(255, 255, 255));
        jlb6.setText("jLabel6");

        jlb7.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb7.setForeground(new java.awt.Color(255, 255, 255));
        jlb7.setText("jLabel16");

        jLabel65.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\cendol.jpg")); // NOI18N

        jLabel66.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\tawur.jpg")); // NOI18N

        jLabel67.setIcon(new javax.swing.ImageIcon("C:\\Users\\lenovo\\Documents\\Matkul SM5\\menu\\escampur.jpg")); // NOI18N

        jlb3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb3.setForeground(new java.awt.Color(255, 255, 255));
        jlb3.setText("jLabel3");

        jlb4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jlb4.setForeground(new java.awt.Color(255, 255, 255));
        jlb4.setText("jLabel4");

        StjBtn.setText("Add to Cart");
        StjBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StjBtnActionPerformed(evt);
            }
        });

        StjQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        pociBtn.setText("Add to Cart");
        pociBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pociBtnActionPerformed(evt);
            }
        });

        pociQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        SktQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        cuingQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        CdlQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        TwrQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        CprQty.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));

        SktBtn.setText("Add to Cart");
        SktBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SktBtnActionPerformed(evt);
            }
        });

        cuingCart.setText("Add to Cart");
        cuingCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cuingCartActionPerformed(evt);
            }
        });

        CdlBtn.setText("Add to Cart");
        CdlBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CdlBtnActionPerformed(evt);
            }
        });

        TwrBtn.setText("Add to Cart");
        TwrBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TwrBtnActionPerformed(evt);
            }
        });

        CprBtn.setText("Add to Cart");
        CprBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CprBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(StjBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jdrink1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(StjQty, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                                    .addComponent(jlb1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel62)
                                .addComponent(jLabel63))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(SktBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jdrink3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(13, 13, 13)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(SktQty, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jlb3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel67)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jdrink7, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(CprBtn))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(CprQty)
                                            .addComponent(jlb7))))
                                .addGroup(jPanel7Layout.createSequentialGroup()
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(CdlBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jdrink5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(CdlQty)
                                        .addComponent(jlb5)))))
                        .addGap(0, 213, Short.MAX_VALUE))
                    .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel61)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jdrink2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pociBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jlb2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pociQty)))
                            .addComponent(jLabel64)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jdrink4, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .addComponent(cuingCart, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jlb4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cuingQty)))
                            .addComponent(jLabel66))
                        .addContainerGap(237, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jdrink6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TwrBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlb6)
                            .addComponent(TwrQty, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel62)
                            .addComponent(jLabel61))
                        .addGap(12, 12, 12)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jdrink1)
                                            .addComponent(jlb1))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(StjBtn)
                                            .addComponent(StjQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jdrink2)
                                            .addComponent(jlb2))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(pociBtn)
                                            .addComponent(pociQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(61, 61, 61)
                                .addComponent(jLabel63))
                            .addComponent(jLabel64, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jdrink3)
                                    .addComponent(jlb3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(SktQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(SktBtn)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jdrink4)
                                    .addComponent(jlb4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cuingCart)
                                    .addComponent(cuingQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(229, 229, 229))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGap(559, 559, 559)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(CdlQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(CdlBtn))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel66)
                                    .addComponent(jLabel65))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlb6, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jdrink5)
                                        .addComponent(jlb5)
                                        .addComponent(jdrink6)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(TwrQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TwrBtn))))))
                .addGap(34, 34, 34)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel67)
                        .addGap(16, 16, 16)
                        .addComponent(jdrink7))
                    .addComponent(jlb7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CprQty, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CprBtn))
                .addContainerGap(1658, Short.MAX_VALUE))
        );

        jScrollPane3.setViewportView(jPanel7);

        jLabel70.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("Minuman");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel70))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel70)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        jTabbedPane1.addTab("Minuman", jPanel6);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 690, 540));

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        jLabel44.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Keranjang");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama", "Harga", "Qty", "Total"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        CheckOutBtn.setText("Checkout");
        CheckOutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckOutBtnActionPerformed(evt);
            }
        });

        ResetBtn.setText("Reset Cart");
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });

        btnTotal.setBackground(new java.awt.Color(255, 255, 255));
        btnTotal.setText("Total Pembelian");
        btnTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTotalActionPerformed(evt);
            }
        });
        btnTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnTotalKeyReleased(evt);
            }
        });

        HapusBtn.setText("Hapus Menu");
        HapusBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HapusBtnActionPerformed(evt);
            }
        });

        txtTotal.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        txtTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTotalKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(btnTotal)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(CheckOutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(HapusBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ResetBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel44)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel44)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(HapusBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ResetBtn)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE)
                        .addGap(17, 17, 17)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CheckOutBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 90, 610, 540));

        jLabel45.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 20)); // NOI18N
        jLabel45.setText("KULINER WONG CIREBON");
        getContentPane().add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        jLabel58.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel58.setText("KUWOCI");
        getContentPane().add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    public void penjualanProduk(){
            try{
                int r = NamaMenu.size();
                Connection dbconn = Kuwoci.koneksiDB();                           
                for(int i = 0; i<r;i++){
                    PreparedStatement st = (PreparedStatement)
                    dbconn.prepareStatement("INSERT INTO sales_produk (nama_produk,harga,qty,total,Customer) VALUES ('"+NamaMenu.get(i)+"','"+HargaPerItem.get(i)+"','"+quantity.get(i)+"','"+subtotal.get(i)+"','"+namauser+"')");
                    int hasil = st.executeUpdate();
                }                             
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }       
    }
    
    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        Konsumen_homepage khp = new Konsumen_homepage();
        khp.setVisible(true);
        khp.show();
        dispose();
        khp.pack();
        khp.setLocationRelativeTo(null);
        khp.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_backActionPerformed

    private void jfood9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood9ActionPerformed
        // TODO add your handling code here:
        BuburSop BS = new BuburSop();
        BS.setVisible(true);
        BS.show();
        dispose();
        BS.pack();
        BS.setLocationRelativeTo(null);
        BS.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood9ActionPerformed

    private void jfood1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood1ActionPerformed
        // TODO add your handling code here:
        EmpalGentong EGP = new EmpalGentong();
        EGP.setVisible(true);
        EGP.show();
        dispose();
        EGP.pack();
        EGP.setLocationRelativeTo(null);
        EGP.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood1ActionPerformed

    private void jfood16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood16ActionPerformed
        // TODO add your handling code here:
        KrpUdang KU = new KrpUdang();
        KU.setVisible(true);
        KU.show();
        dispose();
        KU.pack();
        KU.setLocationRelativeTo(null);
        KU.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood16ActionPerformed

    private void jfood18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood18ActionPerformed
        // TODO add your handling code here:
        gapit gpt = new gapit();
        gpt.setVisible(true);
        gpt.show();
        dispose();
        gpt.pack();
        gpt.setLocationRelativeTo(null);
        gpt.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood18ActionPerformed

    private void jfood5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood5ActionPerformed
        // TODO add your handling code here:
        SateAyam SA = new SateAyam();
        SA.setVisible(true);
        SA.show();
        dispose();
        SA.pack();
        SA.setLocationRelativeTo(null);
        SA.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood5ActionPerformed

    private void jfood2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood2ActionPerformed
        // TODO add your handling code here:
        EmpalAsem asem = new EmpalAsem();
        asem.setVisible(true);
        asem.show();
        dispose();
        asem.pack();
        asem.setLocationRelativeTo(null);
        asem.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood2ActionPerformed

    private void jfood3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood3ActionPerformed
        // TODO add your handling code here:
        NasiJamblang NJ = new NasiJamblang();
        NJ.setVisible(true);
        NJ.show();
        dispose();
        NJ.pack();
        NJ.setLocationRelativeTo(null);
        NJ.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood3ActionPerformed

    private void jfood4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood4ActionPerformed
        // TODO add your handling code here:
        NasiLengko NL = new NasiLengko();
        NL.setVisible(true);
        NL.show();
        dispose();
        NL.pack();
        NL.setLocationRelativeTo(null);
        NL.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood4ActionPerformed

    private void jfood8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood8ActionPerformed
        // TODO add your handling code here:
        Docang dc = new Docang();
        dc.setVisible(true);
        dc.show();
        dispose();
        dc.pack();
        dc.setLocationRelativeTo(null);
        dc.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood8ActionPerformed

    private void jfood7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood7ActionPerformed
        // TODO add your handling code here:
        SateKambing SK = new SateKambing();
        SK.setVisible(true);
        SK.show();
        dispose();
        SK.pack();
        SK.setLocationRelativeTo(null);
        SK.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood7ActionPerformed

    private void jfood11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood11ActionPerformed
        // TODO add your handling code here
        PedesanEntog PE = new PedesanEntog();
        PE.setVisible(true);
        PE.show();
        dispose();
        PE.pack();
        PE.setLocationRelativeTo(null);
        PE.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood11ActionPerformed

    private void jfood13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood13ActionPerformed
        // TODO add your handling code here:
        Ketoprak kp = new Ketoprak();
        kp.setVisible(true);
        kp.show();
        dispose();
        kp.pack();
        kp.setLocationRelativeTo(null);
        kp.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood13ActionPerformed

    private void jfood10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood10ActionPerformed
        // TODO add your handling code here:
        Gado gd = new Gado();
        gd.setVisible(true);
        gd.show();
        dispose();
        gd.pack();
        gd.setLocationRelativeTo(null);
        gd.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood10ActionPerformed

    private void jfood12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood12ActionPerformed
        // TODO add your handling code here:
        Rujak rj = new Rujak();
        rj.setVisible(true);
        rj.show();
        dispose();
        rj.pack();
        rj.setLocationRelativeTo(null);
        rj.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood12ActionPerformed

    private void jfood14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood14ActionPerformed
        // TODO add your handling code here:
        tahu tg = new tahu();
        tg.setVisible(true);
        tg.show();
        dispose();
        tg.pack();
        tg.setLocationRelativeTo(null);
        tg.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood14ActionPerformed

    private void jfood15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood15ActionPerformed
        // TODO add your handling code here:
        Serabi srb = new Serabi();
        srb.setVisible(true);
        srb.show();
        dispose();
        srb.pack();
        srb.setLocationRelativeTo(null);
        srb.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood15ActionPerformed

    private void jfood17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood17ActionPerformed
        // TODO add your handling code here:
        KrpKulit krk = new KrpKulit();
        krk.setVisible(true);
        krk.show();
        dispose();
        krk.pack();
        krk.setLocationRelativeTo(null);
        krk.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood17ActionPerformed

    private void jfood19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jfood19ActionPerformed
        // TODO add your handling code here:
        emping epg = new emping();
        epg.setVisible(true);
        epg.show();
        dispose();
        epg.pack();
        epg.setLocationRelativeTo(null);
        epg.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jfood19ActionPerformed
    
    Connection dbconn = Kuwoci.koneksiDB();
    
    private void GtgCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GtgCartActionPerformed
        // TODO add your handling code here:        
        String nama = "Empal Gentong";
        int price;
        price = empal_G;
        int qty = Integer.parseInt(GtgQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});        
    }//GEN-LAST:event_GtgCartActionPerformed

    private void AsmCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AsmCartActionPerformed
        // TODO add your handling code here:
        String nama = "Empal Asem";
        int price = empal_A;
        int qty = Integer.parseInt(AsmQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});       
    }//GEN-LAST:event_AsmCartActionPerformed

    private void JblCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JblCartActionPerformed
        // TODO add your handling code here:
        String nama = "Nasi Jamblang";
        int price = Nasi_jbl;
        int qty = Integer.parseInt(JblQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_JblCartActionPerformed

    private void LkoCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LkoCartActionPerformed
        // TODO add your handling code here:
        String nama = "Nasi Lengko";
        int price = Nasi_lk;
        int qty = Integer.parseInt(LkoQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_LkoCartActionPerformed

    private void ayamCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ayamCartActionPerformed
        // TODO add your handling code here:
        String nama = "Sate Ayam";
        int price = sate_A;
        int qty = Integer.parseInt(ayamQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_ayamCartActionPerformed

    private void kbgCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kbgCartActionPerformed
        // TODO add your handling code here:
        String nama = "Sate Kambing";
        int price = sate_K;
        int qty = Integer.parseInt(KbgQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_kbgCartActionPerformed

    private void entogcartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entogcartActionPerformed
        // TODO add your handling code here:
        String nama = "Pedesan Entog";
        int price = pds_etg;
        int qty = Integer.parseInt(entogQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_entogcartActionPerformed

    private void buryamCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buryamCartActionPerformed
        // TODO add your handling code here:
        String nama = "Bubur Sop Ayam";
        int price = Bbr_sop;
        int qty = Integer.parseInt(buryamQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_buryamCartActionPerformed

    private void kangkunCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kangkunCartActionPerformed
        // TODO add your handling code here:
        String nama = "Rujak Kangkung";
        int price = rujak_k;
        int qty = Integer.parseInt(kangkungQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_kangkunCartActionPerformed

    private void KtpCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KtpCartActionPerformed
        // TODO add your handling code here:
        String nama = "Ketoprak";
        int price = ketoprak;
        int qty = Integer.parseInt(KtpQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_KtpCartActionPerformed

    private void DcgCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DcgCartActionPerformed
        // TODO add your handling code here:
        String nama = "Docang";
        int price = dcg;
        int qty = Integer.parseInt(DcgQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_DcgCartActionPerformed

    private void EpgCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EpgCartActionPerformed
        // TODO add your handling code here:
        String nama = "Emping";
        int price = emping;
        int qty = Integer.parseInt(EpgQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_EpgCartActionPerformed

    private void KulitCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KulitCartActionPerformed
        // TODO add your handling code here:
        String nama = "Kerupuk Kulit";
        int price = krpk_k;
        int qty = Integer.parseInt(KulitQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_KulitCartActionPerformed

    private void TahuCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TahuCartActionPerformed
        // TODO add your handling code here:
        String nama = "Tahu Gejrot";
        int price = tahu_gjr;
        int qty = Integer.parseInt(TahuQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_TahuCartActionPerformed

    private void SrbCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SrbCartActionPerformed
        // TODO add your handling code here:
        String nama = "Serabi";
        int price = surabi;
        int qty = Integer.parseInt(SrbQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_SrbCartActionPerformed

    private void GapitCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GapitCartActionPerformed
        // TODO add your handling code here:
        String nama = "Kue Gapit";
        int price = kue_gpit;
        int qty = Integer.parseInt(GapitQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_GapitCartActionPerformed

    private void UdangCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UdangCartActionPerformed
        // TODO add your handling code here:
        String nama = "Kerupuk Udang";
        int price = krpk_u;
        int qty = Integer.parseInt(UdangQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_UdangCartActionPerformed

    private void gadoCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gadoCartActionPerformed
        // TODO add your handling code here:
        String nama = "Gado-gado Ayam";
        int price = gado_a;
        int qty = Integer.parseInt(gadoQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_gadoCartActionPerformed

    private void jdrink1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink1ActionPerformed
        // TODO add your handling code here:
        tjampolay sirup = new tjampolay();
        sirup.setVisible(true);
        sirup.show();
        dispose();
        sirup.pack();
        sirup.setLocationRelativeTo(null);
        sirup.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink1ActionPerformed

    private void jdrink2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink2ActionPerformed
        // TODO add your handling code here:
        poci tp = new poci();
        tp.setVisible(true);
        tp.show();
        dispose();
        tp.pack();
        tp.setLocationRelativeTo(null);
        tp.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink2ActionPerformed

    private void jdrink7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink7ActionPerformed
        // TODO add your handling code here:
        escampur cpr = new escampur();
        cpr.setVisible(true);
        cpr.show();
        dispose();
        cpr.pack();
        cpr.setLocationRelativeTo(null);
        cpr.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink7ActionPerformed

    private void jdrink4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink4ActionPerformed
        // TODO add your handling code here:
        cuing c = new cuing();
        c.setVisible(true);
        c.show();
        dispose();
        c.pack();
        c.setLocationRelativeTo(null);
        c.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink4ActionPerformed

    private void jdrink3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink3ActionPerformed
        // TODO add your handling code here:
        sekoteng skt = new sekoteng();
        skt.setVisible(true);
        skt.show();
        dispose();
        skt.pack();
        skt.setLocationRelativeTo(null);
        skt.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink3ActionPerformed

    private void jdrink6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink6ActionPerformed
        // TODO add your handling code here:
        esTawuran twr = new esTawuran();
        twr.setVisible(true);
        twr.show();
        dispose();
        twr.pack();
        twr.setLocationRelativeTo(null);
        twr.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink6ActionPerformed

    private void jdrink5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdrink5ActionPerformed
        // TODO add your handling code here:
        cendol cdl = new cendol();
        cdl.setVisible(true);
        cdl.show();
        dispose();
        cdl.pack();
        cdl.setLocationRelativeTo(null);
        cdl.setDefaultCloseOperation(Konsumen_homepage.EXIT_ON_CLOSE);
    }//GEN-LAST:event_jdrink5ActionPerformed

    private void StjBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StjBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Sirup Tjampolay";
        int price = tjampolay;
        int qty = Integer.parseInt(StjQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_StjBtnActionPerformed

    private void pociBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pociBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Teh Poci";
        int price = teh_poci;
        int qty = Integer.parseInt(pociQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_pociBtnActionPerformed

    private void SktBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SktBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Sekoteng";
        int price = sekuteng;
        int qty = Integer.parseInt(SktQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_SktBtnActionPerformed

    private void cuingCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cuingCartActionPerformed
        // TODO add your handling code here:
        String nama = "Cuing";
        int price = hrg_cuing;
        int qty = Integer.parseInt(cuingQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_cuingCartActionPerformed

    private void CdlBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CdlBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Es Cendol";
        int price = es_cdl;
        int qty = Integer.parseInt(CdlQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_CdlBtnActionPerformed

    private void TwrBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TwrBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Es Tawuran";
        int price =es_twr;
        int qty = Integer.parseInt(TwrQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_TwrBtnActionPerformed

    private void CprBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CprBtnActionPerformed
        // TODO add your handling code here:
        String nama = "Es Campur";
        int price = es_cpr;
        int qty = Integer.parseInt(CprQty.getValue().toString());
        int total = price*qty;
        Keranjang k = new Keranjang(nama, price, qty, total);
        NamaMenu.add(k.getnama());
        quantity.add(k.getqty());
        HargaPerItem.add(k.getprice());
        subtotal.add(k.gettotal());
        model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{nama, price, qty, total});
    }//GEN-LAST:event_CprBtnActionPerformed

    private void btnTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTotalActionPerformed
        // TODO add your handling code here:
        sum = totalInvoice();
        txtTotal.setText("Rp"+" "+Integer.toString(sum));
    }//GEN-LAST:event_btnTotalActionPerformed
    
    public int totalInvoice(){
        int tot = 0;
        for(int i = 0; i<jTable1.getRowCount();i++){
            tot = tot + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
        }
        return tot;
    }

    private void HapusBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HapusBtnActionPerformed
        // TODO add your handling code here:
        String tblmenu = model.getValueAt(jTable1.getSelectedRow(), 0).toString();
        String tblhrg = model.getValueAt(jTable1.getSelectedRow(), 1).toString();
        String tblqty = model.getValueAt(jTable1.getSelectedRow(), 2).toString();
        String tbltot = model.getValueAt(jTable1.getSelectedRow(), 3).toString();
        int r =NamaMenu.size();
        int k = KrjMenu.size();
        if(r>0 && k==0){
            NamaMenu.remove(tblmenu);
            HargaPerItem.remove(Integer.valueOf(tblhrg));
            quantity.remove(Integer.valueOf(tblqty));
            subtotal.remove(Integer.valueOf(tbltot));
        }else if(r==0 && k>0){
        
            KrjMenu.remove(tblmenu);
            KrjQty.remove(tblhrg);
            KrjHarga.remove(tblqty);
            KrjTotal.remove(tbltot);
        }else{                      
            NamaMenu.remove(tblmenu);
            HargaPerItem.remove(Integer.valueOf(tblhrg));
            quantity.remove(Integer.valueOf(tblqty));
            subtotal.remove(Integer.valueOf(tbltot));
        }
        
        model.removeRow(jTable1.getSelectedRow());
        int tot=totalInvoice();
        txtTotal.setText("Rp"+" "+Integer.toString(tot));

    }//GEN-LAST:event_HapusBtnActionPerformed
    public void reset(){
        NamaMenu.clear();
        HargaPerItem.clear();
        quantity.clear();
        subtotal.clear();
        
        KrjMenu.clear() ;
        KrjQty.clear() ;
        KrjHarga.clear();
        KrjTotal.clear();
    }
    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
        // TODO add your handling code here:
        jTable1.setModel(new DefaultTableModel(null, new String[]{"Nama", "Harga", "Qty", "Total"}));
        reset();
    }//GEN-LAST:event_ResetBtnActionPerformed

    
    public PageFormat getPageFormat(PrinterJob pj){
    
        PageFormat pf = pj.defaultPage();
        Paper paper = pf.getPaper();    

        double bodyHeight = bHeight;  
        double headerHeight = 5.0;                  
        double footerHeight = 5.0;        
        double width = cm_to_pp(8); 
        double height = cm_to_pp(headerHeight+bodyHeight+footerHeight); 
        paper.setSize(width, height);
        paper.setImageableArea(0,10,width,height - cm_to_pp(1));  
            
        pf.setOrientation(PageFormat.PORTRAIT);  
        pf.setPaper(paper);    

        return pf;
    }
    
    protected static double cm_to_pp(double cm){
        return toPPI(cm * 0.393600787);            
    }
    protected static double toPPI(double inch){            
	return inch * 72d;            
    }
    
    public void wishlistCart(){
        model = (DefaultTableModel)jTable1.getModel();
        for(int i = 0; i< KrjMenu.size(); i++){
            model.addRow(new Object[]{KrjMenu.get(i), KrjHarga.get(i), KrjQty.get(i), KrjTotal.get(i)}); 
        }       
    }
    private void CheckOutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckOutBtnActionPerformed
        if(sum==0 || namauser ==null){
            JOptionPane.showMessageDialog(this, "Mohon Klik Total Pembayaran atau tambahkan menu ke keranjang");
        }else{
        if(saldo<sum){
            JOptionPane.showMessageDialog(this, "Mohon Maaf Saldo Anda Tidak Mencukupi");
        }else{
            curSaldo = saldo;
            saldo = saldo - sum;//lunas - sum
            bal = String.valueOf(saldo);
            
            try{
                Connection dbconn = Kuwoci.koneksiDB();
                Saldo s = new Saldo(saldo, emailUsr);
                s.topUp();
                penjualanProduk();

            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e);
            }            
            
            JOptionPane.showMessageDialog(this, "Pembayaran telah dikonfirmasi");
            bHeight = Double.valueOf(NamaMenu.size());
           
            PrinterJob pj = PrinterJob.getPrinterJob();
            pj.setPrintable(new BillPrintable(), getPageFormat(pj));
            try{
                pj.print();
            }catch(PrinterException ex){
                ex.printStackTrace();
            }
            reset();
        }         
        }
    }//GEN-LAST:event_CheckOutBtnActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnTotalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnTotalKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTotalKeyReleased

    private void txtTotalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalKeyReleased

public class BillPrintable implements Printable {
    public int print(Graphics graphics, PageFormat pageFormat,int pageIndex) throws PrinterException {    
        int r= NamaMenu.size();
        int k = KrjMenu.size();
        int result = NO_SUCH_PAGE;    
            if (pageIndex == 0) {                          
                Graphics2D g2d = (Graphics2D) graphics;    
                double width = pageFormat.getImageableWidth();                               
                g2d.translate((int) pageFormat.getImageableX(),(int) pageFormat.getImageableY()); 

            FontMetrics metrics=g2d.getFontMetrics(new Font("Arial",Font.BOLD,7));            
            
            try{
                int y=20;
                int yShift = 10;
                int headerRectHeight=15;
                int headerRectHeighta=40;         
                
                g2d.setFont(new Font("Monospaced",Font.PLAIN,9));              
                g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                g2d.drawString("              KUWOCI.com                     ",25,y);y+=yShift;
                g2d.drawString("          jln.kesambi no 306                ",25,y);y+=yShift;
                g2d.drawString("               CIREBON                      ",25,y);y+=yShift;
                g2d.drawString("       www.instagram.com/KUWOCI             ",25,y);y+=yShift;
                g2d.drawString("         no telp: 083452687216               ",25,y);y+=yShift;
                g2d.drawString("--------------------------------------------",25,y);y+=headerRectHeight;

                g2d.drawString(" Nama Item                   Harga          ",25,y);y+=yShift;
                g2d.drawString("--------------------------------------------",25,y);y+=headerRectHeight;
                
                if(k!=0){
                    for(int m = 0; m<k; m++){
                            NamaMenu.add(KrjMenu.get(m));
                            quantity.add(KrjQty.get(m));
                            HargaPerItem.add(KrjHarga.get(m));
                            subtotal.add(KrjTotal.get(m)); 
                    }
                    
                    for(int s=0; s<k; s++){
                            g2d.drawString(" "+NamaMenu.get(s)+"                            ",25,y);y+=yShift;
                            g2d.drawString("      "+quantity.get(s).toString()+" * "+HargaPerItem.get(s),25,y); 
                            g2d.drawString("    "+subtotal.get(s).toString(),160,y);y+=yShift;
                    }
             
                        String bayar = String.valueOf(sum);
                        String curBalance = String.valueOf(curSaldo);
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Total       :               "+bayar+"   ",25,y);y+=yShift;
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Cash        :               "+curBalance+"   ",25,y);y+=yShift;//payment.getText();
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Balance     :               "+bal+"   ",25,y);y+=yShift;
  
                        g2d.drawString("********************************************",25,y);y+=yShift;
                        g2d.drawString("              TERIMAKASIH                   ",25,y);y+=yShift;
                        g2d.drawString("********************************************",25,y);y+=yShift;
                        g2d.drawString("         SOFTWARE BY:Kelompok 3             ",25,y);y+=yShift;
                        g2d.drawString("      CONTACT: contact@KUWOCI.com           ",25,y);y+=yShift;  
                }else{
                    for(int s=0; s<r; s++){
                            g2d.drawString(" "+NamaMenu.get(s)+"                            ",25,y);y+=yShift;
                            g2d.drawString("      "+quantity.get(s).toString()+" * "+HargaPerItem.get(s),25,y); 
                            g2d.drawString("    "+subtotal.get(s).toString(),160,y);y+=yShift;
                    }
             
                        String bayar = String.valueOf(sum);
                        String curBalance = String.valueOf(curSaldo);
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Total       :               "+bayar+"   ",25,y);y+=yShift;
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Cash        :               "+curBalance+"   ",25,y);y+=yShift;//payment.getText();
                        g2d.drawString("--------------------------------------------",25,y);y+=yShift;
                        g2d.drawString(" Balance     :               "+bal+"   ",25,y);y+=yShift;
  
                        g2d.drawString("********************************************",25,y);y+=yShift;
                        g2d.drawString("              TERIMAKASIH                   ",25,y);y+=yShift;
                        g2d.drawString("********************************************",25,y);y+=yShift;
                        g2d.drawString("         SOFTWARE BY:Kelompok 3             ",25,y);y+=yShift;
                        g2d.drawString("      CONTACT: contact@KUWOCI.com           ",25,y);y+=yShift;  
                }
            }catch(Exception e){
                e.printStackTrace();
            }

              result = PAGE_EXISTS;    
          }    
          return result;    
    }
}

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(food.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(food.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(food.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(food.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new food().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AsmCart;
    private javax.swing.JSpinner AsmQty;
    private javax.swing.JButton CdlBtn;
    private javax.swing.JSpinner CdlQty;
    private javax.swing.JButton CheckOutBtn;
    private javax.swing.JButton CprBtn;
    private javax.swing.JSpinner CprQty;
    private javax.swing.JButton DcgCart;
    private javax.swing.JSpinner DcgQty;
    private javax.swing.JButton EpgCart;
    private javax.swing.JSpinner EpgQty;
    private javax.swing.JButton GapitCart;
    private javax.swing.JSpinner GapitQty;
    private javax.swing.JButton GtgCart;
    private javax.swing.JSpinner GtgQty;
    private javax.swing.JButton HapusBtn;
    private javax.swing.JButton JblCart;
    private javax.swing.JSpinner JblQty;
    private javax.swing.JSpinner KbgQty;
    private javax.swing.JButton KtpCart;
    private javax.swing.JSpinner KtpQty;
    private javax.swing.JButton KulitCart;
    private javax.swing.JSpinner KulitQty;
    private javax.swing.JButton LkoCart;
    private javax.swing.JSpinner LkoQty;
    private javax.swing.JButton ResetBtn;
    private javax.swing.JButton SktBtn;
    private javax.swing.JSpinner SktQty;
    private javax.swing.JButton SrbCart;
    private javax.swing.JSpinner SrbQty;
    private javax.swing.JButton StjBtn;
    private javax.swing.JSpinner StjQty;
    private javax.swing.JButton TahuCart;
    private javax.swing.JSpinner TahuQty;
    private javax.swing.JButton TwrBtn;
    private javax.swing.JSpinner TwrQty;
    private javax.swing.JButton UdangCart;
    private javax.swing.JSpinner UdangQty;
    private javax.swing.JButton ayamCart;
    private javax.swing.JSpinner ayamQty;
    private javax.swing.JButton back;
    private javax.swing.JButton btnTotal;
    private javax.swing.JButton buryamCart;
    private javax.swing.JSpinner buryamQty;
    private javax.swing.JButton cuingCart;
    private javax.swing.JSpinner cuingQty;
    private javax.swing.JSpinner entogQty;
    private javax.swing.JButton entogcart;
    private javax.swing.JButton gadoCart;
    private javax.swing.JSpinner gadoQty;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jdrink1;
    private javax.swing.JButton jdrink2;
    private javax.swing.JButton jdrink3;
    private javax.swing.JButton jdrink4;
    private javax.swing.JButton jdrink5;
    private javax.swing.JButton jdrink6;
    private javax.swing.JButton jdrink7;
    private javax.swing.JButton jfood1;
    private javax.swing.JButton jfood10;
    private javax.swing.JButton jfood11;
    private javax.swing.JButton jfood12;
    private javax.swing.JButton jfood13;
    private javax.swing.JButton jfood14;
    private javax.swing.JButton jfood15;
    private javax.swing.JButton jfood16;
    private javax.swing.JButton jfood17;
    private javax.swing.JButton jfood18;
    private javax.swing.JButton jfood19;
    private javax.swing.JButton jfood2;
    private javax.swing.JButton jfood3;
    private javax.swing.JButton jfood4;
    private javax.swing.JButton jfood5;
    private javax.swing.JButton jfood7;
    private javax.swing.JButton jfood8;
    private javax.swing.JButton jfood9;
    private javax.swing.JLabel jlb1;
    private javax.swing.JLabel jlb2;
    private javax.swing.JLabel jlb3;
    private javax.swing.JLabel jlb4;
    private javax.swing.JLabel jlb5;
    private javax.swing.JLabel jlb6;
    private javax.swing.JLabel jlb7;
    private javax.swing.JButton kangkunCart;
    private javax.swing.JSpinner kangkungQty;
    private javax.swing.JButton kbgCart;
    private javax.swing.JButton keranjang;
    private javax.swing.JButton pociBtn;
    private javax.swing.JSpinner pociQty;
    private javax.swing.JLabel txtTotal;
    // End of variables declaration//GEN-END:variables
}
