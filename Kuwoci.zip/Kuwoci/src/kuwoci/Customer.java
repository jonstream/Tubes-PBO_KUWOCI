/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import static kuwoci.Konsumen_homepage.namauser;
import static kuwoci.Konsumen_homepage.saldo;
import static kuwoci.LoginUser.emailUsr;

/**
 *
 * @author lenovo
 */
public class Customer extends User {
    public Customer(String username, String email, String password){
        super(username, email, password);
    }
    Connection dbconn = Kuwoci.koneksiDB(); 
    public void insertCustomer() throws SQLException{                 
        PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement("INSERT INTO customer (username,email,password) VALUES ('"+super.getUsername()+"','"+super.getEmail()+"','"+super.getPassword()+"')");
        int hasil = st.executeUpdate();                         
    }
    public void updateNamaCustomer() throws SQLException{
        String sql = "UPDATE `makanan`.`customer` SET `username` = '"+super.getUsername()+"' where (`email`='"+super.getEmail()+"')";      
        String sql2 = "UPDATE `makanan`.`sales_produk` SET `Customer` = '"+super.getUsername()+"' where (`Customer`='"+namauser+"')";
        PreparedStatement st = dbconn.prepareStatement(sql);
        PreparedStatement st2 = dbconn.prepareStatement(sql2);
        st.executeUpdate();
        st2.executeUpdate();
    }
    public void updatePWCustomer() throws SQLException{
        String sql = "UPDATE `makanan`.`customer` SET `password` = '"+super.getPassword()+"' where (`email`='"+super.getEmail()+"')";          
        PreparedStatement st = dbconn.prepareStatement(sql);
        st.executeUpdate();
    }
    public void customerSaldo(String user,int saldo) throws SQLException{
        Saldo newsaldo = new Saldo(saldo, user);
        newsaldo.topUp();
    }
    
        
}
