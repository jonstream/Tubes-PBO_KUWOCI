/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import static kuwoci.LoginUser.emailUsr;

/**
 *
 * @author lenovo
 */
public class wishlist {
    private String nama;
    private String user;
    private int harga;
    Connection dbconn = Kuwoci.koneksiDB();
    public wishlist(String nama, int harga, String user){
        setnama(nama);
        setHarga(harga);
        setuser(user);
    }
    public void setnama(String nama){
        this.nama = nama;
    }
    public void setHarga(int harga){
        this.harga = harga;
    }
    public void setuser(String user){
        this.user = user;
    }
    public String getnama(){
        return nama;
    }
    public int getharga(){
        return harga;
    }
    public String getuser(){
        return user;
    }
    public void addWishlist() throws SQLException{       
        String sql = "INSERT INTO wishlist (NamaMenu,Harga,AkunCustomer) VALUES ('"+this.getnama()+"','"+this.getharga()+"','"+this.getuser()+"')";
        PreparedStatement st = dbconn.prepareStatement(sql);
        st.executeUpdate();
    }
    public void deleteWishlist()throws SQLException{               
        String sql = "delete from wishlist WHERE NamaMenu = '"+this.getnama()+"'" ;
        PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement(sql);
        int hasil = st.executeUpdate();
    }
    /*public void showWishlist() throws SQLException{
        String sql = "select NamaMenu, Harga from wishlist where AkunCustomer = '"+this.getuser()+"'";
        PreparedStatement st = dbconn.prepareStatement(sql);
        st.executeUpdate();
    }*/
}
