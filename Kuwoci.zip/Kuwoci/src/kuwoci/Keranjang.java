/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuwoci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import static kuwoci.Konsumen_homepage.namauser;
import static kuwoci.food.HargaPerItem;
import static kuwoci.food.NamaMenu;
import static kuwoci.food.quantity;
import static kuwoci.food.subtotal;

/**
 *
 * @author lenovo
 */
public class Keranjang {
    private String nama;
    private int price;
    private int qty ;
    private int total;
    Connection dbconn = Kuwoci.koneksiDB();
    public Keranjang(String nama, int price, int qty, int total){
        this.nama = nama;
        this.price = price;
        this.qty = qty;
        this.total = total;
    }
    public String getnama(){
        return nama;
    }
    public int getprice(){
        return price;
    }
    public int getqty(){
        return qty;
    }
    public int gettotal(){
        return total;
    }
    public void bayar() throws SQLException{
        int r = NamaMenu.size();
        for(int i = 0; i<r;i++){
            PreparedStatement st = (PreparedStatement)
            dbconn.prepareStatement("INSERT INTO sales_produk (nama_produk,harga,qty,total,Customer) VALUES ('"+NamaMenu.get(i)+"','"+HargaPerItem.get(i)+"','"+quantity.get(i)+"','"+subtotal.get(i)+"','"+namauser+"')");
            int hasil = st.executeUpdate();
        }           
    }
    
}
